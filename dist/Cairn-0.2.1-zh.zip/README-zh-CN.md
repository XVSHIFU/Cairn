# Cairn（中文版 / Chinese edition）

本整包 = 原版 [oritera/Cairn](https://github.com/oritera/Cairn) + 简体中文本地化：

- `cairn/src/cairn/dispatcher/prompts/zh-CN/` — 中文 agent 提示词（`## Language` 规则要求
  fact/intent/reason 等描述使用简体中文；JSON 键名、id、技术标识符保持原文）
- `cairn/src/cairn/server/static/index.html` — 中英双语 Web 界面，右上角 `EN / 中文` 一键切换
- `cairn-local.sh` — 本地部署辅助脚本（server + dispatcher 一键起停）

## 启用中文

```yaml
# dispatch.yaml 中设置
runtime:
  prompt_group: "zh-CN"     # 英文则用 "default"
```

重启后生效。Web 界面点右上角 `中文` 按钮即可切换语言。

如需把中文单独装到已下载的原版上，请使用同目录 `cairn-zh-CN-0.2.1.zip`（独立增量包）。
